PSD Template from: http://freebiesbug.com/psd-freebies/minimo-minimal-blog-template/

HTML & CSS By Nikolai Rezvoi - https://github.com/nrezvoi/